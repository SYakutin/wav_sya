# Setting up the Environment

Run the `environment_setup` script to install the required libraries and dependencies. The development was done in a Python 3.10.16 environment on an Ubuntu 22.04.05 system.

Note that the data generation and model training code can make use of a GPU, when one is present. For the ONNX models to take advantage of this, you might need to manually set LD_LIBRARY_PATH values for appropriate CUDA library files for the ONNX models to use GPUs correctly.

Additionally, much of the training code is designed to dynamically read data from disk to reduce memory usage. Usage of a fast NVME SSD is strongly reccomended, as streaming data in this way from slower storage devices will significantly slow down training.

# Datasets Utilized

The following datasets were used during data generation to augment the synthetic TTS generations:

- Free Music Archive (https://github.com/mdeff/fma)
- FSD50k (https://zenodo.org/records/4060432)
- RNNoise Contributions (https://media.xiph.org/rnnoise/rnnoise_contributions.tar.gz)
- ACAV100M (https://acav100m.github.io/)

Each of these datasets has its own download and data processing steps, along with their own licenses for usage.

Unless otherwise specified, all audio data from these datasets was converted to single-channel, 16-bit, 16 khz audio.

For the model training, the following pre-prepared features from the openWakeWord encoder were used:

- https://huggingface.co/datasets/davidscripka/openwakeword_features/blob/main/openwakeword_features_ACAV100M_2000_hrs_16bit.npy
- https://huggingface.co/datasets/davidscripka/openwakeword_features/blob/main/validation_set_features.npy

This pre-prepared data can be reproduced as needed using the scripts and examples available in the openWakeWord repository.

# Notes and Comments

## Model Config

The `angela.yml` file defines the configuration parameters used to generate the training data and train the model. Each paramater has a description for what aspect of the model training process that it controls. Note that some paths will need to be updated based on download files and local file structure.

## Generating Data

Two different approaches were utilized to generate the positive training data:

1) Using the Piper TTS model (based on the VITS architecture), which is efficient and can generate a very large amount of data quickly (see the `data_generation.ipynb` notebook)
2) Using the XTTSv2 TTS model to clone speakers from the Common Voice dataset is much slower, but has more variety and quality in the data (see the `xtts_v2_data_generation.ipynb` notebook).

From my testing, approximately 500,000 positive clips generated using the Piper TTS model, combined with 5,000 to 10,000 positive clips with XTTSv2 performed well. This is what was used for the model delivered.

After generating the data, in can be very helpful (especially for the XTTSv2 outputs) to check the quality of the generations using the `openSpeechToIntent` library. In general absolute scores above approximately -0.5 to -0.3 can be considered as good quality. 

## Training the Model

The model was trained using the default training pipeline in openWakeWord, with a few modifications. See the `model_training.ipynb` notebook for full details. This training process relies on several specific approaches that have historically enhanced performance (see the `train_model` and `auto_train` functions in `train.py` in the openWakeWord code). It is possible that a simpler training approach may lead to similar (or even better) performance, and from the experiments conducted during this effort it is likely that the training process could be optimized further. But this would require more validation and testing data to prevent overfitting, which is beyond the scope of this initial effort.

From observation, the following hyperparameters for the default training config have the most impact:

- steps (high values can lead to higher recall, but also higher false activation rates)
- max_negative_weight (similar pattern, higher recall at the cost of higher false activation rates)
- the number of positive and adversarial negative examples to generate

It is also important to note that many aspects of the model training process (data generation, data augmentation, and training) all rely on random variation to increase the diversity of the training data and thus the performance of the model. One disadvantage of this approach is that it is quite difficult to define an exactly reproducible training run, at least without substantial modifications to the code and likely decreased efficiency. Thus, the trained model is reproducible on average, but not exactly.

## Evaluation

All of the model evaluations can be found in the `model_evaluation.ipynb` notebook, including utility functions to get the times of predictions and process multiple files in parallel.

The performance of the model overall is mixed; recall on the test examples with high SNR is good (~90% on the provided validation clips), but on the provided validation recording with ~9.0 dB SNR wakewords with background noise, performance is lower (~72% recall). There are several possible reasons for this, see the additional discussion below. The false activation rate is generally <= 0.5 per hour, estimated using the provided `far_train` audio files.

The default score threshold for an activation is 0.5 (which was used for the numbers presented above), but tuning this value for the target environment and sensitivity towards true activations and false activations can sometimes increase performance significantly.

## Suggested Next Steps

- The data generated with XTTSv2 seems very promising, as it seemed (subjectively) more realistic and captured a higher variety of tones, speaking speed, speaker accents, and audio quality. More experiments where this data is scaled significantly higher might be beneficial.

- Listening to some of the validation data provided, I noticed that sometimes the pronunciation of the word "Angela" sounded very similar to "Angelo" or "an-jell-uh". These words can be added to the `target_phrase` key in the model training config file, if these similar words and alternate pronunciations should also activate the model.

- While not tested, noise suppression on the input audio may help increase the recall of the model, especially for cases where the SNR of the spoken wakeword is relatively low. However, depending on how aggressive the noise cancellation is, it may be neccessary to train the model on data with the noise suppression applied so the model can learn how it changes the audio.

- The quality of the microphone can also have a significant effect on model performance; if you have a known type of microphone and associated DSP chip, collected some training data (both positive and negative clips) and mixing this with the synthetic data can improve performance further.

- The default model training pipeline is optimized for general purpose usage and contains a wide range of background noise types. This makes the model perform reasonably well on average, but more result in sub-optimal performance on specific types of background noise. For example, in my experience speech and babble background noise can be extremely difficult for the model (which may explains the lower than desired performance on the validation example). If this type of noise is expected to be very common in production deployment environments, focusing the model training more directly on this type of noise may further increase performance.

- It's important to remember that the pre-trained encoder used by openWakeWord is a highly compressed representation when compared to the input features (melspectrogram). This is useful for making efficient classification models, but does imply that there are limits for the complexity of the task that the model needs to perform. For example, very low SNR for the wakeword or highly dynamic types of noise may be very difficult for the model as there just isn't much data available in the encoder features. In these cases, a model that operates directly on the input spectrogram may be more effective. See the microWakeWord (https://github.com/kahrendt/microWakeWord) project for a good example of this, though the lack of frozen feature encoder may limit the suitability of this approach for your custom NASP.

- Finally, the last factor that can significantly affect model performance is just the selection of the wakeword, specifically the phoneme combination and how well the model can learn to predict it. In some cases a given wakeword is just difficult to learn, or is so common that keeping the false activation rate low is very difficult. Exploring different types of wakewords can often lead to better performance with even the same training pipeline.